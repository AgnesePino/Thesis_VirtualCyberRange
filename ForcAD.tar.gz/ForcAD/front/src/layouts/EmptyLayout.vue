<template>
    <div id="app">
        <slot />
    </div>
</template>

<style lang="scss">
#app {
    width: 100%;
    height: 100%;
}
</style>
