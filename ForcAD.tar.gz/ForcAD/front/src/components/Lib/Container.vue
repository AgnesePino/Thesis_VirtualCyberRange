<template>
    <div class="container">
        <slot />
    </div>
</template>

<style lang="scss" scoped>
.container {
    margin-left: 4em;
    margin-right: 4em;
}
</style>
