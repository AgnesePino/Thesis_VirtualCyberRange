<template>
    <task-admin />
</template>

<script>
import TaskAdmin from '@/components/Admin/Task.vue';

export default {
    components: {
        TaskAdmin,
    },
};
</script>

<style lang="scss" scoped></style>
