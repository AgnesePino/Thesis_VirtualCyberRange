<template>
    <admin-team-task-log />
</template>

<script>
import AdminTeamTaskLog from '@/components/Admin/TeamTaskLog.vue';

export default {
    components: {
        AdminTeamTaskLog,
    },
};
</script>

<style lang="scss" scoped></style>
