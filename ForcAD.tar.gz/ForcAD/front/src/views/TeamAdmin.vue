<template>
    <team-admin />
</template>

<script>
import TeamAdmin from '@/components/Admin/Team.vue';

export default {
    components: {
        TeamAdmin,
    },
};
</script>

<style lang="scss" scoped></style>
