class JobNames:
    check_action = 'actions.check'
    put_action = 'actions.put'
    get_action = 'actions.get'
    noop_action = 'actions.noop'

    result_handler = 'handlers.result'
    error_handler = 'handlers.error'
