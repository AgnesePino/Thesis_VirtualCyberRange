from .celery_factory import get_celery_app

__all__ = ['get_celery_app']
