from .celery_factory import get_celery_app

celery_app = get_celery_app()
