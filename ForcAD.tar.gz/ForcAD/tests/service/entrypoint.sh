#!/bin/bash -e

cd /app
python3 app.py
